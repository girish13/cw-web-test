//app.factory('restaurants',function($resource,$rootScope){
//    return $resource($rootScope.baseUrl+"/restaurants");
//});

